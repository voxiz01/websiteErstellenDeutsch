# Wie Erstelle Ich Eine Website?

In diesem Projekt arbeiten wir zusammen, um der Klasse IF10_E das Erstellen von Webseiten mithilfe einer Webseite und einer Praxisübung beizubringen.
Inhalt sind eine Einführung in HTML (Mark Merk), CSS (Thiemo Neubauer), JavaScript (Danilo Hristov) und das Publishing von Webseiten, sowie Sprachunterstützung und Barrierefreiheit als kleiner Ausschweif.

#### Gliederung und Aufteilung:
1. HTML (Mark Merk):
    - Syntax
    - Keywords
    - Tags
    - Aufbau
    - Praxisbeispiel
2. CSS (Thiemo Neu):
    - Syntax
    - Keywords
    - Selectors
    - Praxisbeispiel
3. JavaScript (Danilo Hristov):
    - Syntax
    - Keywords
    - Methoden
    - Praxisbeispiel
4. Extras:
    - Publishing (Thiemo)
    - Language Support (Danilo)
    - Barrierefreiheit (Mark)
5. Quellen

#### TODO:
- Praxisbeispiel ausarbeiten
- Erklären warum HTML, CSS UND JavaScript notwendig sind / alle drei entstanden sind anstatt einer programmiersprache für alles

#### Coole Ideen:
- HTML-Editor live in der Webseite mit Renderer
- JavaScript Animationen für Elemente wie die Seiten, wo sich nur der rechte Content ändern
- HTML5-Videos (z.B. YouTube) als Slides mit Autoplay on focus

---

Zum Zusammenarbeiten an diesem Projekt sind CLI- und Git-Kenntnisse notwendig.
Hier ein kleiner Überblick über die gängigsten Befehle:

### CLI-Befehle:

``` $ ls ```

Listet alle Unterordner und Dateien vom aktuellen Dateipfad aus auf.

``` $ cd [directory] ```

Wechselt den aktuellen Dateipfad auf den angegebenen Ordner/Location

``` $ cd .. ```

Wechselt den aktuellen Dateipfad auf den übergeordneten Ordner

``` $ mkdir [name] ```

Kreiert einen Ordner mit angegebenem Namen im aktuellen Dateipfad

``` $ touch [name] ```

Kreiert eine Datei mit angegebenem Namen und Endung im aktuellen Dateipfad

``` $ rm [file] ```

Löscht die angegebene Datei

``` $ mv [file/directory] [target-directory] ```

Versetzt die angegebene Datei oder den Ordner an die angegebene Stelle

### Git-Befehle:

#### Repositories anlegen

``` $ git init [project-name] ```

Legt ein neues lokales Repository mit dem angegebenen Namen vom aktuellen Dateipfad aus an

``` $ git clone [url] ```

Klont ein Projekt in den aktuellen Dateipfad und lädt seine gesamte Versionshistorie herunter

#### Änderungen vornehmen

``` $ git add [file] ```

Fügt eine Datei zum Tracken hinzu

``` $ git add . ```

Fügt alle Dateien zum Tracken hinzu

``` $ git commit -m "[descriptive message]" ```

Speichert alle Änderungen mit einer Beschreibung

#### Änderungen gruppieren

``` $ git branch ```

Listet alle lokalen Branches im aktuellen Repository auf

``` $ git checkout -b [branch-name] ```

Erzeugt einen neuen Branch

``` $ git checkout [branch-name] ```

Wechselt auf den angegebenen Branch und aktualisiert das Arbeitsverzeichnis

#### Änderungen synchronisieren

``` $ git push -u origin [branch] ```

Pusht alle Commits auf dem lokalen Branch zu GitLab

``` $ git pull ```

Pullt die Historie vom externen Repository und aktualisiert die Änderungen vom Server
