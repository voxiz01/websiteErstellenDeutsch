function flyout() {
    let element = document.getElementById("flyout");
    element.addEventListener("click", e => {
    document.getElementById("hiddenFlyout").style.display = "block";
    })
}